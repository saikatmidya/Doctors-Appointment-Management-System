<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="icon" href="logo1.png">
		<!-- Author Meta -->
		<meta name="author" content="Colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Doctor Finder</title>
		<script src="typed.js"></script>


		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">=
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">
			<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/main.css">
		</head>
		<body>

			<!-- Start Header Area -->
			<header class="default-header">
				<div class="container">
					<div class="header-wrap">
						<div class="header-top d-flex justify-content-between align-items-center">
							<div class="logo">
								<a href="#home"><img src="logo1.png"  height="100" width="130" alt=""></a>
							</div>
							<div class="main-menubar d-flex align-items-center">
								<nav class="hide">
									<a href="#home">Home</a>
									<a href="#service">Services</a>
									<a href="#appoinment">Appoinment</a>
									<a href="#consultant">Consultants</a>

								</nav>
								<div class="menu-bar"><span class="lnr lnr-menu"></span></div>
							</div>
						</div>
					</div>
				</div>
			</header>
			<!-- End Header Area -->


			<!-- start banner Area -->
			<section class="banner-area relative" id="home">
				<div class="container">
						<div class="row fullscreen align-items-center justify-content-center">
							<div class="banner-content col-lg-6 col-md-12">
								<h1  class="text-uppercase">
									We are the team <br>
									of excellence
								</h1>
								<p>
								
									<form action="./show/login.php" method="post">
								</p> <button name="submit" value="submit" class="primary-btn2 mt-20 text-uppercase ">FIND DOCTORS<span class="lnr lnr-arrow-right"></span></button>
								</form>
							</div>
							<div class="col-lg-6 d-flex align-self-end img-right">
								<img class="img-fluid" src="img/header-img.png" alt="">
							</div>
						</div>
				</div>
			</section>
			<!-- End banner Area -->

			<!-- Start feature Area -->
			<section class="feature-area section-gap" id="service">
				<div class="container">
					<div class="row">
						<div class="col-lg-6">
							<div class="single-feature d-flex flex-row pb-30">
								<div class="icon">
									<span class="lnr lnr-rocket"></span>
								</div>
								<div class="desc">
									<h4 class="text-uppercase">24/7 emergency</h4>
									<p>AMBULANCE SERVICE<br>
										The Mission Hospital , Durgapur <br> <a href="tel:+91 086875 00500">Phone: 086875 00500</a>
									</p>
								</div>
							</div>
							<div class="single-feature d-flex flex-row pb-30">
								<div class="icon">
									<span class="lnr lnr-chart-bars"></span>
								</div>
								<div class="desc">
									<h4 class="text-uppercase">X-Ray Service</h4>
									<p>
										Scan -x Medical Centre <br> Address: City Center, Durgapur, West Bengal 713216
                                                <br><a href="tel:+91 76999 92514">Phone: 076999 92514</a>
									</p>
								</div>
							</div>
							<div class="single-feature d-flex flex-row">
								<div class="icon">
									<span class="lnr lnr-bug"></span>
								</div>
								<div class="desc">
									<h4 class="text-uppercase">Intensive Care</h4>
									<p>
										The Mission Hospital, Durgapur<br>100 bedded critical care unit,a fully computerized pneumatic chute system(Sumetzberger, Germany).<br><a href="tel:+91 086875 00500">Phone: 086875 00500</a>
									</p>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="single-feature d-flex flex-row pb-30">
								<div class="icon">
									<span class="lnr lnr-heart-pulse"></span>
								</div>
								<div class="desc">
									<h4 class="text-uppercase">24/7 emergency</h4>
									<p>BLOOD BANK<br>
										Bidhannagar Subdivisional Blood Bank <br> Address: Bidhannagar, Durgapur, West Bengal 713206
									</p>
								</div>
							</div>
							<div class="single-feature d-flex flex-row pb-30">
								<div class="icon">
									<span class="lnr lnr-paw"></span>
								</div>
								<div class="desc">
									<h4 class="text-uppercase">X-Ray Service</h4>
									<p>
										Modern X-ray and Durgapur Laboratory <br>Address: Industrial Area, Durgapur, West Bengal 713201
										<br><a href="tel:0343 255 241">Phone: 0343 255 2415</a>
									</p>
								</div>
							</div>
							<div class="single-feature d-flex flex-row">
								<div class="icon">
									<span class="lnr lnr-users"></span>
								</div>
								<div class="desc">
									<h4 class="text-uppercase">Intensive Care</h4>
									<p>
										IQ City Medical College Hospital <br> 24 bedded  Intensive Care Unit (ICU) is a highly specialized,
										13 bedded coronary care unit (CCU)<br><a href="tel:0343 2608888">Emergency No:- 0343 - 2608888</a>
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- End feature Area -->
			<div class="container text-center alert alert-dismissible alert-warning ">
				<h4 class="display-4 text-success" style="font-size: 30px;"><img src="smile.gif" height="50px" width="50px">Laughter a day keeps the doctor away<img src="smile.gif" height="50px" width="50px"></h4>
				<p class="display-6 mt-3" style="font-size: 25px;" id="ajax"></p>
				<button style="outline:none; border:none;"  id="load" align="center"><img src="refresh.gif" height="50" width="80"></button>


			<!-- Start about Area -->
			<section class="about-area" id="appoinment">
				<div class="container-fluid">
					<div class="row d-flex justify-content-end align-items-center">
						<div class="col-lg-6 col-md-12 about-left no-padding">
							<img class="img-fluid" src="img/about-img.jpg" alt="">
						</div>
						<div class="col-lg-6 col-md-12 about-right no-padding">
							<h1 style="margin-top: 10px;">Book an <br> Appoinment</h1>
							<form class="booking-form"  method="post" action="process.php">
								 	<div class="row">
								 		<div class="col-lg-12 d-flex flex-column">
							 				<input name="name" placeholder="Patient name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Patient name'" class="form-control mt-20" required="" type="text" required>
								 		</div>

								 		<div class="col-lg-12 d-flex flex-column">
							 				<input name="email" placeholder="Patient name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" class="form-control mt-20" required="" type="email" required>
								 		</div>

							 			<div class="col-lg-6 d-flex flex-column">
											<input name="phone" placeholder="Phone" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Phone'" class="form-control mt-20" required="" type="text" required>
										</div>
										<div class="col-lg-6 d-flex flex-column">
											<input id="datepicker2" name="date" class="single-in mt-20"  onblur="this.placeholder = 'Appoinment date'" type="date" placeholder="Appoinment date" required>
										</div>
										

										<div class="col-lg-12 flex-column">
											<textarea class="form-control mt-20" name="message"><?php
											$con=new mysqli("localhost", "root", "" ,"doctor");
										if(isset($_POST['cid']))
									{
	$a=$_POST['cid'];
	$sql="SELECT * FROM doctors WHERE id='$a';";
	$result=$con->query($sql);
	if($result->num_rows>0)
	{
		while($r=$result->fetch_assoc())
		{
		 echo "Doctor Name:- ".$r['Name'].
											"\nSpecialties :-".$r['Specialties'].
											"\nDegrees:- ".$r['Degrees'].
											"\nLocation:- ".$r['Location'].
											"\nAvailable:- ".$r['Available'].
											"\nContact Number:- ".$r['Contact'];}}}?></textarea> <p style="float: right;"><i>*E-Mail will be send to the Email ID</i></p>
												
										</div>

										<div class="col-lg-12 d-flex justify-content-end send-btn">
											<button type="submit" name="submit" value="submit" style="margin-bottom: 10px;" class="primary-btn mt-20 text-uppercase ">Send Information<span class="lnr lnr-arrow-right"></span></button>

										</div>

										<div class="alert-msg"></div>
									</div>
					  		</form>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- End about Area -->

			<!-- Start consultans Area -->
			<section class="consultans-area section-gap" id="consultant">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="col-md-9 pb-80 header-text">
							<h1  id="here"></h1>
							<p>
							
							</p>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-3 col-md-3 vol-wrap">
							<div class="single-con">
								<div class="content">
								    <a href="#" target="_blank">
								      <div class="content-overlay"></div>
								  		 <img class="content-image img-fluid d-block mx-auto"  src="img/mission.jpg" alt="">
								      	<div class="content-details fadeIn-bottom">
								      		<a href="http://themissionhospital.com/" target="_blank"><h4>The Mission</h4>
								      		<p>
								      			Bidhannagar, Durgapur
								      		</p></a>
								      	</div>
								    </a>
								 </div>
							</div>
						</div>
						<div class="col-lg-3 col-md-3 vol-wrap">
							<div class="single-con">
								<div class="content">
								    <a href="#" target="_blank">
								      <div class="content-overlay"></div>
								  		 <img class="content-image img-fluid d-block mx-auto" src="img/h1.jpg"  alt="">
								      	<div class="content-details fadeIn-bottom">
								      		<a href="http://www.healthworldhospitals.com/doctors" target="_blank"><h4>HealthWorld Hospital</h4>
								      		<p>
								      			Gandhi More, Commercial Area, Durgapur, West Bengal 713216
								      		</p></a>
								      	</div>
								    </a>
								 </div>
							</div>
						</div>
						<div class="col-lg-3 col-md-3 vol-wrap">
							<div class="single-con">
								<div class="content">
								    <a href="#" target="_blank">
								      <div class="content-overlay"></div>
								  		 <img class="content-image img-fluid d-block mx-auto" src="img/vh.jpg"  alt="">
								      	<div class="content-details fadeIn-bottom">
								      		<a href="https://www.vivekanandahospital.com/" target="_blank"><h4>Vivekanada Hospital</h4>
								      		<p>
								      			Dr Zakir Hussain Ave, Bidhannagar, Durgapur, West Bengal 713206
								      		</p></a>
								      	</div>
								    </a>
								 </div>
							</div>
						</div>
						<div class="col-lg-3 col-md-3 vol-wrap">
							<div class="single-con">
								<div class="content">
								    <a href="#" target="_blank">
								      <div class="content-overlay"></div>
								  		 <img class="content-image img-fluid d-block mx-auto"  src="img/iq.jpg" alt="">
								      	<div class="content-details fadeIn-bottom">
								      		<a href="https://www.narayanahealth.org/hospitals/durgapur/iq-city-narayana-multispeciality-hospital" target="_blank"><h4>IQ City Medical College Hospital</h4>
								      		<p>
								      			IQ City Rd, Durgapur, West Bengal 713206
								      		</p></a>
								      	</div>
								    </a>
								 </div>
							</div>
						</div>

					</div>
				</div>
			</section>
			<!-- End consultans Area -->

			<!-- Start fact Area -->
			
<div class="container-fluid"> <a href="bmi.php" style="cursor: pointer; width: 500px;"><button type="button" class="btn btn-outline-info btn-lg btn-block">BMI Calculation</button></div></a>
				
			
			<!-- end fact Area -->

			<!-- Start blog Area -->
			<section class="blog-area section-gap">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-md-8 pb-30 header-text">
							<h1>Our Recent Blogs</h1>
							<p>
							
							</p>
						</div>
					</div>
					<div class="row">
						<div class="single-blog col-lg-4 col-md-4">

							<img class="f-img img-fluid mx-auto" src="img/b1.jpg" alt="">
							<h4>
								<a href="#">The Beauty Side Effects You Don't Know About</a>
							</h4>
							<p>
								sure, cosmetics make you look good, but just like all things too good to be true, the positive benefits of using such products can take a toll on your health.According to studies, the average woman uses 12 personal care products a day containing 168 different chemicals.Another study, by the Northwestern University School of Medicine in Evanston, Illinois, has also revealed that complaints made against beauty goods more than doubled from 2015 to 2016, with haircare products topping the list.According to the university, there were more than 5,000 events reported to the FDA from 2004 to 2016, with 1,591 incidents reported in 2016 alone.
							</p>
							<div class="bottom d-flex justify-content-between align-items-center flex-wrap">
								<div>
									<img class="" src="" alt="">
									<a href="#"><span>ANNIE TOMLIN</span></a>
								</div>
								<div class="meta">
									13th Dec
									<span class="lnr lnr-heart"></span> 15
									<span class="lnr lnr-bubble"></span> 04
								</div>
							</div>
						</div>
						<div class="single-blog col-lg-4 col-md-4">
							<img class="f-img img-fluid mx-auto" src="img/b2.jpg" alt="">
							<h4>
								<a href="#">Harmful effects of supplements</a>
							</h4>
							<p>
								A study published today in The New England Journal of Medicine found that adverse effects of supplements were responsible for an average of about 23,000 emergency department (ED) visits per year. That’s a lot for something that is supposed to be good for you.
 								Young adults weren’t the only ones affected. Many children under 4 years of age suffered allergic reactions or digestive symptoms (nausea, vomiting, abdominal pain) from unsupervised, accidental ingestion of vitamins.
							</p>
							<div class="bottom d-flex justify-content-between align-items-center flex-wrap">
								<div>
									
									<a href="#"><span>Susan Farrell, MD</span></a>
								</div>
								<div class="meta">
									13th Dec
									<span class="lnr lnr-heart"></span> 15
									<span class="lnr lnr-bubble"></span> 04
								</div>
							</div>
						</div>
						<div class="single-blog col-lg-4 col-md-4">
							<img class="f-img img-fluid mx-auto" src="img/b3.jpg" alt="">
							<h4>
								<a href="#">control your blood pressure</a>
							</h4>
							<p>
								Exercise is one of the best things you can do to lower high blood pressure,Regular exercise helps make your heart stronger and more efficient at pumping blood, which lowers the pressure in your arteries.In fact, 150 minutes of moderate exercise, such as walking, or 75 minutes of vigorous exercise, such as running, per week can help lower blood pressure and improve your heart health.
							</p>
							<div class="bottom d-flex justify-content-between align-items-center flex-wrap">
								<div>
									
									<a href="#"><span>Mark Wiens</span></a>
								</div>
								<div class="meta">
									13th Dec
									<span class="lnr lnr-heart"></span> 15
									<span class="lnr lnr-bubble"></span> 04
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- end blog Area -->

			<!-- start footer Area -->
			<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						
						<div class="col-lg-6  col-md-8">
							<div class="single-footer-widget mail-chimp">
								<h6 class="mb-20">Contact Us</h6>
								<p>
									17/4 Ranapratap Road, A-Zone , Durgapur - 713204 West Burdwan
								</p>
								<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3656.607504261898!2d87.28531724994014!3d23.582536084597134!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39f76dc5cefad9a3%3A0x2f09e068a84e0d27!2s17%2C%204%2C%20Rana%20Pratap%20Rd%2C%20A-Zone%2C%20Durgapur%2C%20West%20Bengal%20713205!5e0!3m2!1sen!2sin!4v1568792819615!5m2!1sen!2sin" width="300" height="200" frameborder="0" style="border:0; box-shadow: 2px 3px 5px gray;" allowfullscreen=""></iframe>
								<h3><a href="tel:+91 9093 132 2270">Call Us:+91 9093 132 2270</a></h3>
								<h3><a href="mailto:sbdgp.95@gmail.com?subject=subject text">Email Us: sbdgp.95@gmail.com</a></h3>
							</div>
						</div>
						<div class="col-lg-6  col-md-12">
							<div class="single-footer-widget newsletter">
								<h6>Newsletter</h6>
								<p>You can trust us. we only send promo offers, not a single spam.</p>
								<div id="mc_embed_signup">
									<form target="_blank" novalidate="true" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="form-inline">

										<div class="form-group row" style="width: 100%">
											<div class="col-lg-8 col-md-12">
												<input name="EMAIL" placeholder="Enter Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email '" required="" type="email">
												<div style="position: absolute; left: -5000px;">
													<input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="" type="text">
												</div>
											</div>

											<div class="col-lg-4 col-md-12">
												<button class="nw-btn primary-btn">Subscribe<span class="lnr lnr-arrow-right"></span></button>
											</div>
										</div>
										<div class="info"></div>
									</form>
								</div>
							</div>
						</div>
					</div>

					<div class="row footer-bottom d-flex justify-content-between">
						<p class="col-lg-8 col-sm-12 footer-text m-0">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
							Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="" target="_blank">Subha Bhattacharjee,Saikat Midya,Mojahid Mollah,Subham Debnath</a>
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						</p>
						<div class="col-lg-4 col-sm-12 footer-social">
							<a href="#"><i class="fa fa-facebook"></i></a>
							<a href="#"><i class="fa fa-twitter"></i></a>
							<a href="admin/index.php"><i class="fa fa-user-circle-o"></i></a>

						</div>
					</div>
				</div>
			</footer>
			<!-- End footer Area -->

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.nice-select.min.js"></script>
			<script src="js/jquery.sticky.js"></script>
			<script src="js/parallax.min.js"></script>
			<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>
			<script src="js/waypoints.min.js"></script>
			<script src="js/jquery.counterup.min.js"></script>
			<script src="js/main.js"></script>
				<script type="text/javascript">
		$.getJSON('https://official-joke-api.appspot.com/random_joke',function(data){

	
	$('#ajax').html("<span class='text-primary'>"+data.setup+"</span><br> <span class='text-danger'>"+data.punchline+"</span>");

	
})
		$("#load").click(function(){
				$.getJSON('https://official-joke-api.appspot.com/random_joke',function(data){

	
	$('#ajax').html("<span class='text-primary mb-2'>"+data.setup+"</span><br> <span class='text-danger'style='margin:5px;'>"+data.punchline+"</span>");

	
})

		})
	
  var typed5 = new Typed('#here', {
    strings: ['Some of the Best Hospital', 'In Durgapur', 'Private Hospital', 'Best Facility' ,'Corporate Hospitals' ,'Best Doctors'],
    typeSpeed: 20,
    backSpeed: 20,
    
    shuffle: true,
    smartBackspace: false,
    loop: false
  });

	</script>
		</body>
	</html>
