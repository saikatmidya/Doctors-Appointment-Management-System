<?php session_start(); ?>

<?php 
if(isset($_POST['submit']))
{

   $Specialties=$_POST['Specialties'];
   //$Name=$_POST['Name'];
  //print_r($_POST);
   $conn=mysqli_connect("localhost","root","","doctor"); 
   $sql="SELECT * FROM doctors WHERE Specialties='$Specialties'; ";
  
   $query=mysqli_query($conn,$sql);
   //print_r($query);
   $n=mysqli_num_rows($query);
   $result=mysqli_fetch_array($query);
   //print_r($result);
   if($n>0)
   {
     $_SESSION['Specialties']=$Specialties ;

 header('location:appointments.php');
}
else
  {
header('location:login.php');

  }
}
?>
<!DOCTYPE html>
<html lang="en">
<!-- login23:11-->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <title>Preclinic - Medical & Hospital - Bootstrap 4 Admin Template</title>
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <!--[if lt IE 9]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
  <style type="text/css">
    option{
      font-size: 18px;
      color: #2e86de;
    }
    @media(min-width: 700px)
    {
      #here{
        width: 500px;
        font-size: 20px;
      }
    }
  </style>

 <script>

    function random_do()
    {
      var a=document.getElementById("special").value;
      if(a=="General Physician")
        {
          here.value="General Physician";
        }
        if(a=="Pediatrician")
        {
          here.value="Pediatrician";
        }
        if(a=="Gynecologist")
        {
          here.value="Gynecologist";
        }
        if(a=="Cardiologist")
        {
          here.value="Cardiologist";
        }
        if(a=="Psychiatrist")
        {
          here.value="Psychiatrist";
        }
        if(a=="Dermatologist")
        {
          here.value="Dermatologist";
        }
        if(a=="Urologist")
        {
          here.value="Urologist";
        }
        if(a=="Gastroenterologist")
        {
          here.value="Gastroenterologist";
        }
         if(a=="Nephrologist")
        {
          here.value="Nephrologist";
        }

           if(a=="ENT")
        {
          here.value="ENT";
        }
        
            if(a=="Neurologist")
        {
          here.value="Neurologist";
        }
        if(a=="Orthopaedic")
        {
          here.value="Orthopaedic";
        }


    }
    
  </script>


    <div class="main-wrapper account-wrapper">
        <div class="account-page">
			<div class="account-center">
				<div class="account-box">
                    <form action="" method="POST" class="form-signin">
						<div class="account-logo">
                            <a href="index-2.html"><img src="assets/img/logo-dark.png" alt=""></a>
                        </div>
                        <div class="form-group">
                          
                            <label>TYPE OF SYMPTOMS</label>
                            
                            <select name="Specialties" id="special" onchange="random_do()" class="form-control" ><option> select</option>
  <option  value="General Physician">Common cold/fever/any kind of health Hazards</option>
  <option  value="Pediatrician">Diseases of childrens</option>
  <option  value="Gynecologist">Diseases of the female reproductive organs</option>
  <option  value="Cardiologist">Heart diseases and heart abnormalities</option>
  <option  value="Psychiatrist">Diagnosis and treatment of mental illness</option>
  <option  value="Dermatologist">Problems with your skin, hair, nails etc</option>
  <option  value="Urologist">Disorders of the urinary system</option>
  <option  value="Gastroenterologist">Disorders of the stomach and intestines</option>
  <option  value="Nephrologist">Diseases of the kidneys</option>
  <option  value="ENT">Diseases of ears, nose and throat</option>
  <option  value="Neurologist">Organic disorders of nerves and the nervous system</option>
  <option  value="Orthopaedic">Diseases of deformities of bones</option>
  
</select>
                        </div>

                        <div class="form-group">
                          
                            <label>TYPE OF DOCTORS</label><br>
                            
                      <input align="center" style=" text-align: center; width: 400px; outline: none; border:none; border-bottom:2px #54a0ff solid;" type="text" id="here" disabled="" placeholder="Select your SYMPTOM from above">
                        </div>
                        
                       
                        <div class="">
                            <button type="submit" name="submit" class="btn btn-primary account-btn">Search</button>
      <a href="http://localhost/medical/index.php" class="btn btn btn-primary btn-rounded float-right"><i class=""></i> BACK </a>
                        </div>
                        
                    </form>

                </div>
			</div>
        </div>

    </div>

    <script src="assets/js/jquery-3.2.1.min.js"></script>
	<script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/app.js"></script>
</body>


<!-- login23:12-->
</html>