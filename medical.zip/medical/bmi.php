<!DOCTYPE html>
<html>
<head>
	<link rel="icon" href="logo1.png">
	<title>BMI | Calculator</title>
	<link rel="stylesheet" type="text/css" href="//staticresource.s3.amazonaws.com/template/css/themes/preston.css">
	<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Raleway:400,700,100,100italic,200,200italic,300,300italic,400italic,500,500italic,600,600italic,700italic,800,800italic,900,900italic">
	<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Lora:400,400italic,700,700italic">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="https://s3-us-west-2.amazonaws.com/s.cdpn.io/67439/basic.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/eqcss/1.2.1/EQCSS.min.js"></script>
</head>
<body>
	<style type="text/css">
		body {
  max-width: 500px;
  background: transparent !important;
}
input {
  display: block;
  margin: 0 0 1em 0;
  padding: .4em .5em;
  width: 100%;
  height: 40px;
  outline: none; 
}
[type=number] {
  display: block;
  margin: 0 0 1em 0;
  padding: .4em .5em;
  width: 100%;
  height: 40px;
  outline: none;
  border: 1px solid rgba(255,255,255,.7);
  border-radius: 2px;
  background: rgba(255,255,255,.5);
  box-shadow: rgba(0,0,0,.15) 0 1px 0;
  color: rgba(0,0,0,.7);
  font-weight: 400;
  font-size: 12pt;
  transition: all .2s ease-in-out;
  -webkit-appearance: none;
  appearance: none;
  -moz-appearance: none;
  font-family: 'Source Sans Pro', 'Open Sans', Roboto, 'HelveticaNeue-Light', 'Helvetica Neue Light', 'Helvetica Neue', 'Myriad Pro', 'Segoe UI', Myriad, Helvetica, 'Lucida Grande', 'DejaVu Sans Condensed', 'Liberation Sans', 'Nimbus Sans L', Tahoma, Geneva, Arial, sans-serif;
}
[type=number]:focus {
  outline: none;
  border-color: orange;
  box-shadow: #fc0 0 0 3px;
}
	</style>
<h1>BMI Calculator</h1>
<h3>Weight</h3>
<input id=weight type=number value=150 oninput=slider.value=value;bmi()>
<input id=slider type=range min=0 max=650 value=185 oninput=weight.value=value;bmi()>
<h3>Height</h3>
<span>Feet</span>
<input id=feet type=number value=6 onchange=bmi()>
<span>Inches</span>
<input id=inches type=number value=0 onchange=bmi()>
<center><output style="text-center"></output></center>
<div class="container-fluid"> <a href="index.php" style="cursor: pointer;"><button type="button" class="btn btn-primary btn-lg btn-block">Back To The Site</button></div></a>

<script type="text/javascript">
	function bmi(){
  var weight = document.getElementById('weight').value,
      feet = parseInt(document.getElementById('feet').value*12),
      inches = parseInt(document.getElementById('inches').value),
      height = feet + inches,
      output = document.querySelector('output'),
      formula = ~~(weight/(height*height)*703*100)/100,
      category = ''
  if (formula < 18.5){
    category = 'Underweight'
    document.documentElement.style.background = 'orange'
  } else if (18.5 < formula && formula < 25){
    category = 'Normal Weight'
    document.documentElement.style.background = 'lightgreen'
  } else if (25 < formula && formula < 30){
    category = 'Overweight'
    document.documentElement.style.background = 'orange'
  } else if (30 < formula){
    category = 'Obese'
    document.documentElement.style.background = 'indianred'
  }
  output.innerHTML = '<h1>'+formula+'</h1><h2>'+category+'</h2>'
}
bmi()
</script>
</body>
</html>