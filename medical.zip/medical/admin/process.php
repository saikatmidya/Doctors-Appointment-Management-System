<?php 



if (isset($_POST['submit'])) {
	if (isset($_POST['check'])) {
		setcookie('uname',$_POST['username'],time()+30*30);
		setcookie('upass',$_POST['password'],time()+30*30);

	}

  session_start();
  $_SESSION['username']=$_POST['username'];
  $_SESSION['password']=$_POST['password'];
  header('location:process.php');

  

$uname=$_SESSION['username'];
$pass=$_SESSION['password'];



if ($uname=="admin" && $pass=="123") {
	


	header('location:index.php?do=Hello_user_'.$uname);
}
if ($uname=="BCREC" && $pass=="BCREC") {
	


	header('location:index.php?do=Hello_user_'.$uname);
}

else
{	
	
	header("location:login.php?msg=error");
	session_destroy();
}
}

 ?>