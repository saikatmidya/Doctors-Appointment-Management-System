<?php include 'header.php'; ?>


 
<div class="main-panel">  

        <div class="content-wrapper">
          <div class="row">
             
            <div class="col-12 grid-margin stretch-card">

              <div class="card">
                <center><a href="booklist.php"><button type="button"  class="btn btn-outline-warning btn-rounded btn-fw my-3 " style="width: 300px; color: #b71540; font-size: 15px;">&#171; Back To Doctor List</button></center></a></center>
                <div align="center" style="color: #4834d4;"><?php if(isset($_GET['ok'])) {echo "Doctor Details Inserted Successfully.";} ?></div>
                <div class="card-body">
                  <h4 align="center"  style="color: indigo; font-size: 30px; text-shadow: 3px 5px 6px gray;" class="card-title">Doctor Details Input Form</h4>
                  <div id="printy"></div>
                  
                  
                  <form class="forms-sample" method="post" action="input.php">
                     <div class="form-group">
                      <label for="exampleInputEmail3">Specialist</label>
                      <select  name="Specialties" class="form-control"  ><option  > select</option>
  <option style="font-size: 15px;" value="General Physician">General Physician</option>
  <option style="font-size: 15px;" value="Pediatrician">Pediatrician</option>
  <option style="font-size: 15px;" value="Gynecologist">Gynecologist</option>
  <option style="font-size: 15px;" value="Cardiologist">Cardiologist</option>
  <option style="font-size: 15px;" value="Psychiatrist">Psychiatrist</option>
  <option style="font-size: 15px;" value="Dermatologist">Dermatologist</option>
  <option style="font-size: 15px;" value="Urologist">Urologist</option>
  <option style="font-size: 15px;" value="Gastroenterologist">Gastroenterologist</option>
  <option style="font-size: 15px;" value="Nephrologist">Nephrologist</option>
  <option style="font-size: 15px;" value="ENT">ENT</option>
  <option style="font-size: 15px;" value="Neurologist">Neurologist</option>
  <option style="font-size: 15px;" value="Orthopaedic">Orthopaedic</option>
  
</select>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputName1">Name</label>
                      <input type="text" name="name" class="form-control" id="exampleInputName1" placeholder="Name">
                    </div>
                   
                    <div class="form-group">
                      <label for="exampleInputPassword4">Degrees</label>
                      <input type="text" name="degrees" class="form-control" id="exampleInputPassword4" placeholder="Degrees">
                    </div>

                    <div class="form-group">
                      <label for="exampleInputPassword4">Location</label>
                      <input type="text" name="location" class="form-control" id="exampleInputPassword4" placeholder="Location">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword4">Available</label>
                      <input type="text" name="available" class="form-control" id="exampleInputPassword4" placeholder="Available">
                    </div>

                    

                    <div class="form-group">
                      <label for="exampleInputPassword4">Contact Number</label>
                      <input type="text" name="contact" class="form-control" id="exampleInputPassword4" placeholder="Contact">
                      </div>
                   
                    <button  type="submit" name="submit" class="btn btn-primary mr-2">Submit</button>
                    
                  </form>
 
                </div>
              </div>
            </div>

<?php include "footer.php"; ?>

