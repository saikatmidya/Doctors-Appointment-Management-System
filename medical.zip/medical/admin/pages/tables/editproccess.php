<?php 
include "connect.php";
if(isset($_POST['submit']))
{
	$id=trim($_POST['or']);
	$name= mysqli_real_escape_string($conn,$_POST['name']);
	$specialist= mysqli_real_escape_string($conn,$_POST['Specialties']);
	$degrees= mysqli_real_escape_string($conn,$_POST['degrees']);
	$location= mysqli_real_escape_string($conn,$_POST['location']);
	$available= mysqli_real_escape_string($conn,$_POST['available']);
	$contact= mysqli_real_escape_string($conn,$_POST['contact']);
	$sql="UPDATE doctors SET Specialties='$specialist', Name='$name', Degrees='$degrees', Location='$location', Available='$available', Contact='$contact' WHERE ID='$id';";

		
		if($conn->query($sql))
		{
			header('location:doctorlist.php?done=ok');
		}
		else
		{
			echo "Error".$conn->connect_error;
		}

	
	
}
if (isset($_GET['del'])) {
	$a=$_GET['del'];
	$sql= "DELETE FROM doctors WHERE ID='$a'";
	$conn->query($sql);
	header('location:doctorlist.php?delete=deleted');
}

 ?>