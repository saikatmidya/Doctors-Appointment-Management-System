<?php include "header.php"; ?>
<?php include 'connect.php'; ?>

 <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">

                  <!-- User Details -->

                 <!-- Booking Details -->

                  <h3 align="center" style="color:#c0392b; font-size: 30px; text-shadow: 3px 5px 6px gray;" class="card-title">Booking Details</h3>
                  <h4 align="center"  style="color: #079992; font-size: 20px; text-shadow: 3px 5px 10px gray;" class="card-title"><?php if (isset($_GET['delete'])) {
                    echo "Doctor Detail Deleted Successfully ";
                  } 
                  if(isset($_GET['done']))
                  {
                  	echo "Doctor Details Updated Successfully ";
                  }

                  ?></h4>
                  
                  <div class="table-responsive pt-3">
                    <table class="table table-bordered">
                      <thead>
                        <tr class="table-light">
                          <th>
                           Specialties
                          </th>
                          <th>
                           Name
                          </th>
                           <th>
                           Degree
                          </th>
                          <th >
                            Location
                          </th>
                          <th>
                            Available
                          </th>
                          <th>
                          Contact Number
                          </th>
                          
                            <th>
                           Update
                          </th>
                          <th>
                          	Delete
                          </th>

                         
                        </tr>
                      </thead>
                      <tbody>
                             <?php 
                      include "connect.php";
                      $sql="SELECT * FROM doctors;";
                      $result=$conn->query($sql);
                      if ($result->num_rows>0) {
                        
                      while ($r=$result->fetch_assoc()) {
                        
                      

                       ?>
                        <tr class="">
                          <td class="table-danger">
                           <?php  echo $r['Specialties']; ?>
                          </td>
                          <td class="table-primary">
                           <?php echo $r['Name']; ?>
                          </td>
                           <td class="table-success">
                           <?php echo $r['Degrees']; ?>
                          </td>
                          <td  style="" class="table-warning">
                            <?php  echo $r['Location']; ?>
                          </td>
                          <td class="table-info">
                            <?php echo $r['Available']; ?>
                          </td>
                          <td class="table-success"> 
                            <?php echo $r['Contact']; ?>
                          </td>
                          
                            <td class="table-danger">
                            <a href="edit.php?id=<?php echo $r['ID'];?>"><button type="button" class="btn btn-outline-warning btn-icon-text">
                          Edit</a>
                          <i class="ti-file btn-icon-append"></i>                          
                        </button>
                          </td>
                          <td class="table-danger">
                            <a href="editproccess.php?del=<?php echo $r['ID'];?>"><button type="button" class="btn btn-outline-danger btn-icon-text">
                          Delete</a>
                                                  
                        </button>
                          </td>
                         
                        </tr>
                        <tr class="table-warning">
                         
                        </tr>
                        <tr class="table-danger">
                          
                        </tr>
                        <tr class="table-success">
                          
                        </tr>
                        <tr class="table-primary">
                          
                        </tr>
                         <?php }} ?>
                      </tbody>
                    </table>
                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>


<?php include "footer.php"; ?>