
<?php include "header.php"; ?>
    
      <!-- partial -->
      <div class="main-panel">  

        <div class="content-wrapper">
          <div class="row">
             
            <div class="col-12 grid-margin stretch-card">

              <div class="card">
                <center><a href="doctorlist.php"><button type="button"  class="btn btn-outline-warning btn-rounded btn-fw my-3 " style="width: 300px; color: #b71540; font-size: 15px;">&#171; Back To Doctor List List</button></center></a></center>
                <div class="card-body">
                  <h4 align="center"  style="color: indigo; font-size: 30px; text-shadow: 3px 5px 6px gray;" class="card-title">Doctor List Update Form</h4>
                  
                  
                  <form class="forms-sample" action="editproccess.php" method="post">
                    <div class="form-group">
                      <label for="exampleInputName1">ID</label>
                      <input type="text" class="form-control" name="or" id="exampleInputName1" value=" <?php if(isset($_GET['id'])){ echo $_GET['id'];} ?>" readonly>
                    </div>
                    <?php 
                    include "connect.php";
                    $id=$_GET['id'];
                    $sql="SELECT * FROM doctors where ID='$id';";
                    $result=$conn->query($sql);
                    if ($result->num_rows>0) {
                      while ($r=$result->fetch_assoc()) {
                     

                     ?>
                    <div class="form-group">
                      <label for="exampleInputEmail3">Specialist</label>
                      <select  name="Specialties" class="form-control" value ="<?php echo $r['Specialties'];?>"  ><option selected="<?php echo $r['Specialties'];?>"  > select</option>
  <option style="font-size: 15px;" value="General Physician">General Physician</option>
  <option style="font-size: 15px;" value="Pediatrician">Pediatrician</option>
  <option style="font-size: 15px;" value="Gynecologist">Gynecologist</option>
  <option style="font-size: 15px;" value="Cardiologist">Cardiologist</option>
  <option style="font-size: 15px;" value="Psychiatrist">Psychiatrist</option>
  <option style="font-size: 15px;" value="Dermatologist">Dermatologist</option>
  <option style="font-size: 15px;" value="Urologist">Urologist</option>
  <option style="font-size: 15px;" value="Gastroenterologist">Gastroenterologist</option>
  <option style="font-size: 15px;" value="Nephrologist">Nephrologist</option>
  <option style="font-size: 15px;" value="ENT">ENT</option>
  <option style="font-size: 15px;" value="Neurologist">Neurologist</option>
  <option style="font-size: 15px;" value="Orthopaedic">Orthopaedic</option>
  
</select>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputName1">Name</label>
                      <input type="text" name="name" value ="<?php echo $r['Name'];?>"  class="form-control" id="exampleInputName1" placeholder="Name">
                    </div>
                   
                    <div class="form-group">
                      <label for="exampleInputPassword4">Degrees</label>
                      <input type="text" name="degrees" class="form-control" value ="<?php echo $r['Degrees'];?>" id="exampleInputPassword4" placeholder="Degrees">
                    </div>

                    <div class="form-group">
                      <label for="exampleInputPassword4">Location</label>
                      <input type="text" name="location" class="form-control" value ="<?php echo $r['Location'];?>" id="exampleInputPassword4" placeholder="Location">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword4">Available</label>
                      <input type="text" name="available" value ="<?php echo $r['Available'];?>" class="form-control" id="exampleInputPassword4" placeholder="Available">
                    </div>

                    

                    <div class="form-group">
                      <label for="exampleInputPassword4">Contact Number</label>
                      <input type="text" name="contact" class="form-control" value ="<?php echo $r['Contact'];?>" id="exampleInputPassword4" placeholder="Contact">
                      </div>
                   <?php }} ?>
                 
                    <button type="submit" name="submit" class="btn btn-primary mr-2">Update</button>
                    
                  </form>
                </div>
              </div>
            </div>
            
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
        <?php include "footer.php"; ?>