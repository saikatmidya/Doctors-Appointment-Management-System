<?php 
include 'connect.php';
if (isset($_POST['submit'])) {
	if (isset($_POST['check'])) {
		
   $name=$_POST['username'];
   $email=$_POST['email'];
   $country=$_POST['country'];
   $password=$_POST['password'];
   $status='no';
   $sql="INSERT into user(username,email,country,password,status) values('$name','$email','$country','$password','$status');";
  
   if($conn->query($sql))
   {
   	header('location:userlogin.php?all=value_inserted_successfully');
   }
   else
   {
   		echo "cannot enter";
   }

	}
	else
	{
			header('location:userreg.php?ms=check_terms');
	}
	
}

 ?>