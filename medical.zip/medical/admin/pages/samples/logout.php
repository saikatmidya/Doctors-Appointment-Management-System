<?php 
session_start();
include 'connect.php';
if (isset($_SESSION)) {
	$username=$_SESSION['cname'];
	$password=$_SESSION['cpassword'];
	$sql="UPDATE user SET status='no' where username='$username' and password='$password';";
	$conn->query($sql);
	unset($_SESSION['cname']);
	unset($_SESSION['cpassword']);
	
	header('location:../../../index.php');
}

 ?>