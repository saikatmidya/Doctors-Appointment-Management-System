<?php 
include "connect.php";
if(isset($_POST['submit']))
{
$a=$_POST['username'];
$b=$_POST['email'];
$c=$_POST['old_password'];
$d=$_POST['new_password'];

$sql="SELECT password from user where username='$a' and email='$b'; ";
$result=$conn->query($sql);
if($result->num_rows>0)
{
  while($r=$result->fetch_assoc())
    $p=$r['password'];
  if($p===$c)
  {
    $sql="UPDATE user set password='$d' where username='$a' and email='$b'; ";
    
    $conn->query($sql);
    header('location:changepass.php?all=changed');
  }
  else
  {
  header('location:changepass.php?no=error');
  }
}
else
{
  header('location:changepass.php?ms=invalid');
}
}

 ?>


<?php 
session_start();

if (isset($_SESSION['cname']) && isset($_SESSION['cpassword'])){
  header('location:logout.php');
}


 ?>


<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Sign In | Users</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="../../vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="../../vendors/base/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="../../css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="../../images/logo1.png" />
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-stretch auth auth-img-bg">
        <div class="row flex-grow">
          <div class="col-lg-6 d-flex align-items-center justify-content-center">
            <div class="auth-form-transparent text-left p-3">
              <div align="center" class="brand-logo">
                <a href="/project/"><img src="../../images/logo1.png" alt="logo"></a>
              </div>
              <h4>Change Password</h4>
              <div id="printy" style="text-shadow: 2px 3px 5px gray; font-size: 35px; font-weight: lighter;"
              ><h6  style="font-size: 20px;" class="font-weight-light"><?php if (isset($_GET['ms'])) {
 echo "

<font style=\"color:#b71540\"; >Invalid Credentials.</font>
  ";
}
elseif (isset($_GET['no'])) {
  echo "<font style=\"color:#e55039\";>Old Password does not Match.</font>
  ";
}
elseif(isset($_GET['all'])) {
  echo "<font style=\"color:#079992\";>Password has been changed.</font>
  ";
}
else
{
  echo "Enter username and old password";}?></h6></div>
              <form class="pt-3" method="post" action="">
                <div class="form-group">
                  <label for="exampleInputEmail">Username</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="ti-user text-primary"></i>
                      </span>
                    </div>
                    <input type="text" name="username" class="form-control form-control-lg border-left-0" id="exampleInputEmail" required placeholder="Username">
                  </div>
                </div>

                   <div class="form-group">
                  <label for="exampleInputEmail">Email</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="ti-user text-primary"></i>
                      </span>
                    </div>
                    <input type="text" name="email" class="form-control form-control-lg border-left-0" id="exampleInputEmail" placeholder="Email">
                  </div>
                </div>
                 <div class="form-group">
                  <label for="exampleInputPassword">Old Password</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="ti-lock text-primary"></i>
                      </span>
                    </div>
                    <input type="password" name="old_password" class="form-control form-control-lg border-left-0"  required placeholder="Old Password" >                        
                  </div>
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword">New Password</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="ti-lock text-primary"></i>
                      </span>
                    </div>
                    <input type="password" name="new_password" class="form-control form-control-lg border-left-0" id="oldpass" required placeholder="New Password" onkeyup="panda()">                        
                  </div>
                </div>
                   <div class="form-group">
                  <label for="exampleInputPassword">Retype New Password</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="ti-lock text-primary"></i>
                      </span>
                    </div>
                    <input type="password" name="re_password" class="form-control form-control-lg border-left-0" id="newpass" placeholder="Retype New Password" onkeyup="panda()" required>                      
                  </div>
                </div>
                 <div class=" text-center">
                      <span id="here"></span>
                    </label>
                  
                 

                </div>
               
                <div class="my-2">

                  <input type="submit" id="click" name="submit" value="Change" class="btn btn-block btn-outline-primary btn-lg font-weight-medium auth-form-btn">
                </div>
                
                <div class="text-center mt-4 font-weight-light">
                  Don't have an account? <a href="userreg.php" class="text-primary">Create</a>
                </div>
                
              </form>
            </div>
          </div>
          <div class="col-lg-6 login-half-bg d-flex flex-row">
            <p class="text-white font-weight-medium text-center flex-grow align-self-end">Copyright &copy; 2019  All rights reserved.</p>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="../../vendors/base/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="../../js/off-canvas.js"></script>
  <script src="../../js/hoverable-collapse.js"></script>
  <script src="../../js/template.js"></script>
  <script src="../../js/todolist.js"></script>
  <!-- endinject -->
  <script type="text/javascript">
    function panda()
    { 
      var a= document.getElementById('oldpass').value;
      var b= document.getElementById('newpass').value;
      var out;
      
      if(b===a && a.length>0 && b.length>0)
      {
         out="MATCHED";
        var result=out.fontcolor("green");
        $('#here').show();
        $('#click').show(1000);
      }
        else if(b.length == 0){
         out="NO INPUT";
        var result=out.fontcolor("blue");
        $('#here').hide();
         $('#click').hide();
      }
      
      else{
         out="NOT-MATCHED";
        var result=out.fontcolor("red");
        $('#here').show();
         $('#click').hide();
      }
      
        document.getElementById('here').innerHTML=result;

      
    }
  </script>




</body>

</html>
