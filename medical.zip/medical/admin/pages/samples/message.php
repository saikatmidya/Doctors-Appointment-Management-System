<?php 

echo "<font style=\"color:green\";>Found Password.</font>";

 ?>