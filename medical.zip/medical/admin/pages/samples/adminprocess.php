<?php 

include 'connect.php'; 

if (isset($_POST['submit'])) {
  if (isset($_POST['check'])) {

   $name=$_POST['username'];
   $email=$_POST['email'];
   $country=$_POST['country'];
   $password=$_POST['password'];
   $status='no';
   $sql="INSERT into admin values('$name','$email','$country','$password','$status');";
   if($conn->query($sql)==true)
   {
   	header('location:adminreg.php?msg=value_inserted_successfully');
   }
   else
   {
   		echo "cannot enter";
   }


}

else
{
	header('location:adminreg.php?ms=Accept_terms');
}
}
