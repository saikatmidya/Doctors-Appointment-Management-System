<?php 

include "connect.php";
session_start();
$uname=$_POST['username'];
$pass=$_POST['password'];


$sql="SELECT * FROM user where username='$uname' AND password='$pass';";
$result=$conn->query($sql);
if($result->num_rows>0)
{
	$sq="UPDATE user set status='yes' where username='$uname' AND password='$pass'; ";
	$conn->query($sq);
$_SESSION['cname']=$uname;
$_SESSION['cpassword']=$pass;

	header('location:../../../index.php?msg='.$uname);
}
else
{	
	
	header("location:userlogin.php?ms=error");
	
}
$conn->close();

 ?>