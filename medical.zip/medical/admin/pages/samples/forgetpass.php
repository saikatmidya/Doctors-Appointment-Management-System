
<?php 
session_start();
include 'connect.php';
if (isset($_POST['submit'])) {
  $a=$_POST['username'];
  $b=$_POST['email'];
  $sql="SELECT password FROM user where username='$a' AND email='$b';";
  $result=$conn->query($sql);
if ($result->num_rows==1) {
 $r=$result->fetch_assoc();
 $_SESSION['pass']= $r['password'];
 


 header('location:frgt_passuser.php?yes=found');

}
else
{
 header('location:frgt_passuser.php?no=error');
}
}
 ?>