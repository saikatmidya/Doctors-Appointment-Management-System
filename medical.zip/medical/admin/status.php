
 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>
 	<a href="index.php"><font style="font-size: 40px;text-shadow: 2px 3px 5px gray;">&#8666;Admin Panel</font></a>
 	<style type="text/css">
 		body{
 		background: #CAC531;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #F3F9A7, #CAC531);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #F3F9A7, #CAC531); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

 		}
 		h1{
 			color: #192a56;
 			text-shadow: 2px 3px 8px white;
 		}
 		th{
 			color:#c23616;
 			font-size: 25px;
 			text-shadow: 2px 3px 5px gray;
 			border-radius: 15px;
 		}
 		tr{
 			text-align: center;
 			border-bottom: 5px solid orange;
 		}
 		#name{
 			width: 300px;
 			height: 50px;
 		}
 		#row{
 			height: 30px;
 		}
 		table,tr,td,th{
 			
 			border-bottom: 3px solid #82589F;
 			border-right: 1px solid #82589F;
 			color:#2C3A47;
 			outline: none;
 			padding:8px;
 			border-collapse: collapse;
 			font-size: 18px;

 		}
 		tr:nth-child(even){
 			background:#70a1ff;
 		}
 	</style>
 	<h1 align="center">Booking Information</h1>
 <table >
 	<th>order_id</th>
 	<th id="name">name</th>
 	<th>email</th>
 	<th>start</th>
 	<th>destination</th>
 	<th>time</th>
 	<th>Date</th>
 	<th>comfort</th>
 	<th>Adults</th>
 	<th>Children</th>
 	<th>message</th>

 	<?php 
include 'connect.php';

$sql="SELECT * from booking;";
$result=$conn->query($sql);
if ($result->num_rows>0) {
	while ($row=$result->fetch_assoc()) {
		echo "<tr id='row'><td>".$row['order_id']."</td><td>".$row['name']."</td><td>".$row['email']."</td><td>".$row['start']."</td><td>".$row['destination']."</td><td>".$row['time']."</td><td>".$row['date']."</td><td>".$row['comfort']."</td><td>".$row['adults']."</td><td>".$row['children']."</td><td>".$row['message']."</td></tr>";
		
	}
	echo "</table>";
}


 ?>






 </body>
 </html>