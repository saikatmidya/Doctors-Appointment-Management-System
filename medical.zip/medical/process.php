<?php
include 'PHPMailer/PHPMailerAutoload.php';
if (isset($_POST['submit'])) {
	
$name=$_POST['name'];
$date=$_POST['date'];
$mail=new PHPMailer;
$mail->Host='smtp.gmail.com';
$mail->Port=587;
$mail->SMTPAuth=true;
$mail->SMTPSecure="tls";
$mail->Username="reapercoder95@gmail.com";
$mail->Password="reapercoder95";
$message=$_POST['message'];
$mail->setFrom('doctor_finder@gmail.com');
$mail->addAddress($_POST['email']);
$mail->isHTML(true);
$mail->AddEmbeddedImage('logo1.png', 'logo');
$mail->Subject='Your Booking Details';
$mes="<!DOCTYPE html><body>";
	$mes .="<img align='center' src='cid:logo'><br><h2 style='color:red;text-shadow:2px 3px 8px gray;'>Hi ".$name."</h1>";
	$mes .= "<p style='color:#3742fa;font-size:18px;'>Your Booking has been confirmed at ".$date."</p>"; 
	$mes .="<p style='color:#0984e3;font-size:18px;'>".$message."</p>";
	$mes .="<p style='color:#3742fa;font-size:15px;'> For any changes you can reach us on +91 (897) 105 562. Thanks for Consulting Us.</p>";
	$mes .="<h3 style='color:#F79F1F;'>Doctor Finder</h3>";
	$mes .="<h4 style='color:#0a3d62;'>17/4 Ranapratap Road, A-Zone , Durgapur - 713204 West Burdwan</h4>";
	$mes .="</body></html>";
$mail->Body=$mes;
$mail->send();

header('location:index.php?ok=done');
}

?>
