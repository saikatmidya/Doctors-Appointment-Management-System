-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2019 at 06:42 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctor`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `ID` int(10) NOT NULL,
  `Specialties` varchar(255) DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Degrees` varchar(255) DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `Available` varchar(255) DEFAULT NULL,
  `Contact` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`ID`, `Specialties`, `Name`, `Degrees`, `Location`, `Available`, `Contact`) VALUES
(1, 'General Physician', 'Dr B B Senapati', 'MBBS,MD', 'City Medical Stores', 'Tuesday', 9434250388),
(2, 'Pediatrician', 'Dr. Swagata Lahiri', 'M.B.B.S , MD', 'HealthWorld Hospitals', 'Thrusday (5:30pm)', 9732381504),
(3, 'Gynecologist', 'Dr Subrata Dutta', 'M.D(G&O),D.G.O(CAL)', 'Apollo Avenue, Bidhannagar', 'SUNDAY-FRIDAY(9 am)', 9339738443),
(4, 'Orthopaedic', 'Dr. S.Chatterjee', 'M.B.B.S(NUB), D.ortho.(cal)', 'Chatterjee Medical,B-zone', 'Tuesday & Saturday(7pm)', 9832172079),
(5, 'General Physician', 'Dr. B. D. Ghosh', 'M.B.B.S, M.D, DNB(P) N, PGT(com Med)', 'Chatterjee Medicine Store', 'SATURDAY(6:30PM)', 7430917228),
(6, 'Orthopaedic', 'Dr.Dibakar Roy', 'M.S(Ortho),A.O Fello(SWITZERLAND)', 'HealthWorld Hospital', 'TUESDAY', 8170052836),
(7, 'Dermatologist', 'Dr. Bidisha Guha Niyogi', 'DVD,MD(SKIN/LEPROSY)', 'Mission Hospital', 'MONDAY(9:30am)', 9635026508),
(8, 'Cardiologist', 'Dr. Nadeem Afroz', 'M.D, D.M', 'Mission Hospital', 'MONDAY-SATURDAY((9:30am)', 8687500500),
(9, 'Cardiologist', 'Dr. Tapan Kumar Matia', 'M.D, D.N.B', 'Mission Hospital', 'MONDAY_SATURDAY(10am)', 8687500500),
(10, 'Neurologist', 'Dr. Snigdhendu Ghosh', 'M.B.B.S, D.C.H, M.D, D.M', 'Mission Hospital', 'MONDAY_SATURDAY(11am)', 8687500500),
(11, 'Neurologist', 'Dr. Debasish Roy', 'M.B.B.S, M.D, D.M', 'Mission Hospital', '3rd SATURDAY & SUNDAY(10am)', 8687500500),
(12, 'Gynecologist', 'Dr. Dipanwita Sen', 'M.B.B.S, M.D, MRCOG', 'Mission Hospital', 'MONDAY & FRIDAY(10am)', 8687500500),
(13, 'Pediatrician', 'Dr. Dibyendu Chakraborty', 'M.B.B.S, D.C.H, M.D', 'Mission Hospital', 'TUESDAY(3:30pm)', 8687500500),
(14, 'Gastroenterologist', 'Dr. Md. Ashif Ali Ahmed', 'M.B.B.S, M.D, D.M', 'Mission Hospital', 'MONDAY(3pm)', 8687500500),
(15, 'Gastroenterologist', 'Dr. Lalan Kumar', 'M.B.B.S, M.D, D.M', 'Mission Hospital', 'MONDAY-SATURDAY(11am)', 8687500500),
(16, 'Dermatologist', 'Dr. Raghubir Banerjee', 'M.B.B.S, M.D', 'Mission Hospital', 'THRUSDAY(4pm)', 8687500500),
(17, 'Nephrologist', 'Dr. Deepak Kumar', 'M.B.B.S, M.D, D.M', 'Mission Hospital', 'MONDAY-SATURDAY(12am)', 8687500500),
(18, 'ENT', 'Dr. Nishant Kumar', 'M.B.B.S, M.S', 'Mission Hospital', 'MONDAY-SATURDAY(11am)', 8687500500),
(19, 'ENT', 'Dr. S.K Jha', 'M.S(ENT), M.B.B.S', '32, Upendra Kishore Path', 'SUNDAY(9am)', 8335055714),
(20, 'Psychiatrist', 'Dr. Manish Roy', 'M.B.B.S, M.D', 'Mission Hospital', 'MONDAY-FRIDAY(10am)', 8687500500),
(21, 'Psychiatrist', 'Dr. Kinshuk Karmakar', 'M.B.B.S, P.G.D.P.C', 'Trinayani Medicine', 'TUESDAY & THRUSDAY(6:30pm)', 9064179421),
(22, 'Urologist', 'Dr Partha Sarathi Chanda', 'MBBS(CAL), FRCS(EDIN)', 'DURGAPUR CITY CLINIC & NURSING HOME', 'MONDAY(12pm)', 3432546600),
(23, 'Urologist', 'Dr. Ajit J. Thomas', 'MBBS, MS, M.Ch.', 'Mission Hospital', 'SATURDAY(9am)', 8687500500);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
